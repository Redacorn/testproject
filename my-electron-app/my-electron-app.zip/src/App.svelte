<script>
    let message = "Hello, Electron + Svelte + Tailwind!";
</script>

<main class="h-screen flex items-center justify-center bg-gray-100">
    <h1 class="text-4xl font-bold text-blue-600">{message}</h1>
</main>

<style>
    main {
        font-family: Arial, sans-serif;
    }
</style>
